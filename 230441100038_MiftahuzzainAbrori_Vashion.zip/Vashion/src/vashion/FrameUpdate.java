package vashion;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import static vashion.FromAdmin.NamaAsli;
import static vashion.FromAdmin.gambar;
import static vashion.FromAdmin.hargaUp;
import static vashion.FromAdmin.idUp;
import static vashion.FromAdmin.namaUp;
import static vashion.FromAdmin.pasword;
import static vashion.FromAdmin.sizeUp;
import static vashion.FromAdmin.username;
import static vashion.FromAdmin.warnaUp;


public class FrameUpdate extends javax.swing.JFrame {

    Connection conn;
    private JLabel dateLabel;
    String NamaAsli = "";
    
    public String getIdUp() {
        return up_id.getText();
    }

    public String getNamaUp() {
        return up_nama.getText();
    }

    public String getWarnaUp() {
        return up_warna.getText();
    }

    public String getSizeUp() {
        return cmb_up_size.getSelectedItem().toString();
    }

    public String getHargaUp() {
        return up_harga.getText();
    }
    
    public ImageIcon getGambarUp() {
        return (ImageIcon) up_gambar.getIcon();
    }
    

    
    public FrameUpdate() {
        initComponents();
        conn = koneksi.getConnection();
        
        dateLabel = new JLabel();
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        dateLabel.setText(today.format(formatter));

        add(dateLabel);
    }

    class SaveData extends FrameBuat{
        String nama="", warna="", size="", harga="", foto="";
        public SaveData(){
            nama = up_nama.getText();
            warna = up_warna.getText();
            size = cmb_up_size.getSelectedItem().toString();
            harga = up_harga.getText();
            
        }
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        up_nama = new javax.swing.JTextField();
        up_id = new javax.swing.JTextField();
        up_gambar = new javax.swing.JLabel();
        Pilih = new javax.swing.JButton();
        btn_view = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        cmb_up_size = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        up_warna = new javax.swing.JTextField();
        up_harga = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 102, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 204, 0), new java.awt.Color(255, 255, 0), null, new java.awt.Color(255, 204, 0)));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("ID            :");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, -1, -1));
        jPanel1.add(up_nama, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 90, 280, 30));

        up_id.setEditable(false);
        jPanel1.add(up_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 40, 280, 30));

        up_gambar.setBackground(new java.awt.Color(255, 255, 255));
        up_gambar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        up_gambar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        up_gambar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel1.add(up_gambar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 220, 220));

        Pilih.setFont(new java.awt.Font("Lucida Fax", 1, 12)); // NOI18N
        Pilih.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vashion/Icon Simpan.png"))); // NOI18N
        Pilih.setText("Update Product");
        Pilih.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PilihActionPerformed(evt);
            }
        });
        jPanel1.add(Pilih, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 520, 220, 40));

        btn_view.setFont(new java.awt.Font("Lucida Fax", 1, 18)); // NOI18N
        btn_view.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vashion/Icon View.png"))); // NOI18N
        btn_view.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_view.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_viewActionPerformed(evt);
            }
        });
        jPanel1.add(btn_view, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 520, 60, 40));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Warna   :");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Harga   :");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, -1, -1));

        cmb_up_size.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "39", "40", "41", "M", "L", "XL" }));
        jPanel1.add(cmb_up_size, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 190, 280, 30));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Size       :");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, -1, -1));
        jPanel1.add(up_warna, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 140, 280, 30));
        jPanel1.add(up_harga, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 240, 280, 30));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nama     :");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, -1, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vashion/Create Text.png"))); // NOI18N
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 280, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 582, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public byte[] getExistingImageBytes() {
        byte[] imageBytes = null;
        int productId = Integer.parseInt(up_id.getText());

        String sql = "SELECT gambar FROM vashion WHERE id_nama = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setInt(1, productId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    imageBytes = rs.getBytes("gambar");
                }
            }
        }catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Gagal mengambil gambar dari database: " + e.getMessage());
        }
        return imageBytes;
    }
    
    public void LoadUpdate() {

    try {
        String sqlIdNama = "SELECT id_nama FROM vashion WHERE nama = ? LIMIT 1";
        PreparedStatement psIdNama = conn.prepareStatement(sqlIdNama);
        psIdNama.setString(1, NamaAsli);
        ResultSet rsIdNama = psIdNama.executeQuery();

        Integer idNama = null;
        if (rsIdNama.next()) {
            idNama = rsIdNama.getInt("id_nama");
        }
        rsIdNama.close();
        psIdNama.close();

        if (idNama == null) {
            JOptionPane.showMessageDialog(null, "Data id_nama tidak ditemukan untuk nama: " + NamaAsli);
            return;
        }

        String sqlIdUser = "SELECT id_user FROM login WHERE username = ? LIMIT 1";
        PreparedStatement psIdUser = conn.prepareStatement(sqlIdUser);
        psIdUser.setString(1, username);
        ResultSet rsIdUser = psIdUser.executeQuery();

        Integer idUser = null;
        if (rsIdUser.next()) {
            idUser = rsIdUser.getInt("id_user");
        }
        rsIdUser.close();
        psIdUser.close();

        if (idUser == null) {
            JOptionPane.showMessageDialog(null, "Data id_user tidak ditemukan untuk username: " + username);
            return;
        }
        
        String namaProduk = up_nama.getText();
        String sqli = """
            INSERT INTO updata (id_nama, NamaAwal, namaUp, id_user, tanggal)
            VALUES (?, ?, ?, ?, ?)
            """;
        PreparedStatement psi = conn.prepareStatement(sqli);
        psi.setInt(1, idNama);
        psi.setString(2, NamaAsli);
        psi.setString(3, namaProduk);
        psi.setInt(4, idUser);
        psi.setString(5, dateLabel.getText());

        psi.executeUpdate();
        psi.close();
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat memasukkan data ke tabel transaksi: " + e.getMessage());
    }
    }
    
    private void PilihActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PilihActionPerformed
    
        SaveData a = new SaveData();
        if (a.nama.equals("") || a.warna.equals("") || a.size.equals("") || a.harga.equals("")) {
            JOptionPane.showMessageDialog(null, "Harap Mengisikan Deskripsi");
        }else {
        int hargaProdukInt;
            try {
                hargaProdukInt = Integer.parseInt(up_harga.getText());
            }catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Harga harus berupa angka bulat!");
                return;
            }

            int option = JOptionPane.showConfirmDialog(null, "Apakah Anda ingin mengganti gambar?", "Ganti Gambar", JOptionPane.YES_NO_OPTION);
            byte[] img = null;
            ImageIcon icn = null;

            if (option == JOptionPane.YES_OPTION) {
            try {
                JFileChooser chooser = new JFileChooser();
                chooser.showOpenDialog(null);
                File f = chooser.getSelectedFile();

                img = Files.readAllBytes(f.toPath());
                icn = new ImageIcon(img);

                int labelWidth = 235;
                int labelHeight = 235;

                int imageWidth = icn.getIconWidth();
                int imageHeight = icn.getIconHeight();

                double scaleX = (double) labelWidth / (double) imageWidth;
                double scaleY = (double) labelHeight / (double) imageHeight;
                double scale = Math.min(scaleX, scaleY);

                Image scaledImage = icn.getImage().getScaledInstance((int) (scale * imageWidth), (int) (scale * imageHeight), Image.SCALE_SMOOTH);
                up_gambar.setIcon(new ImageIcon(scaledImage));

            }catch (IOException ex) {
                Logger.getLogger(FrameBuat.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat memuat gambar: " + ex.getMessage());
            }
            }else {
                img = getExistingImageBytes();
                icn = new ImageIcon(img);
                int labelWidth = 235;
                int labelHeight = 235;

                int imageWidth = icn.getIconWidth();
                int imageHeight = icn.getIconHeight();

                double scaleX = (double) labelWidth / (double) imageWidth;
                double scaleY = (double) labelHeight / (double) imageHeight;
                double scale = Math.min(scaleX, scaleY);

                Image scaledImage = icn.getImage().getScaledInstance((int) (scale * imageWidth), (int) (scale * imageHeight), Image.SCALE_SMOOTH);
                up_gambar.setIcon(new ImageIcon(scaledImage));
            }

        int id = Integer.parseInt(up_id.getText());
        String namaProduk = up_nama.getText();
        String warnaProduk = up_warna.getText();
        String ukuranProduk = cmb_up_size.getSelectedItem().toString();
        
        LoadUpdate();
    
        String sql = "UPDATE  vashion SET nama = ?, warna = ?, size = ?, harga = ?, gambar = ? WHERE id_nama = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, namaProduk);
            ps.setString(2, warnaProduk);
            ps.setString(3, ukuranProduk);
            ps.setInt(4, hargaProdukInt);
            ps.setBytes(5, img);
            ps.setInt(6, id);

            int rowsUpdated = ps.executeUpdate();
            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(null, "Product Is Save");
            } else {
                JOptionPane.showMessageDialog(null, "Produk dengan ID tersebut tidak ditemukan !!");
            }
        }catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Gagal memperbarui data: " + e.getMessage());
        }
    }
        System.out.println(NamaAsli);
    }//GEN-LAST:event_PilihActionPerformed

    private void btn_viewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_viewActionPerformed

        String idUp = getIdUp();
        String namaUp = getNamaUp();
        String warnaUp = getWarnaUp();
        String sizeUp = getSizeUp();
        String hargaUp = getHargaUp();
        ImageIcon gambar = getGambarUp();
        
        FromAdmin formAdmin = new FromAdmin(NamaAsli,username, pasword, idUp, namaUp, warnaUp, sizeUp, hargaUp, gambar);
        formAdmin.setNamaFinal(username);    
        formAdmin.setTelpFinal(pasword);
        formAdmin.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btn_viewActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrameLogin().setVisible(true);
                new FrameUpdate().setVisible(false);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Pilih;
    private javax.swing.JButton btn_view;
    public javax.swing.JComboBox<String> cmb_up_size;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    public javax.swing.JLabel up_gambar;
    public javax.swing.JTextField up_harga;
    public javax.swing.JTextField up_id;
    public javax.swing.JTextField up_nama;
    public javax.swing.JTextField up_warna;
    // End of variables declaration//GEN-END:variables
}
