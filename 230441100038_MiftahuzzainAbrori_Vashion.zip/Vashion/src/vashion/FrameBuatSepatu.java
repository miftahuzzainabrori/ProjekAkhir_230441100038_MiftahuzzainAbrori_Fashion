package vashion;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import static vashion.FromAdmin.NamaAsli;
import static vashion.FromAdmin.gambar;
import static vashion.FromAdmin.hargaUp;
import static vashion.FromAdmin.idUp;
import static vashion.FromAdmin.namaUp;
import static vashion.FromAdmin.pasword;
import static vashion.FromAdmin.sizeUp;
import static vashion.FromAdmin.username;
import static vashion.FromAdmin.warnaUp;


public class FrameBuatSepatu extends javax.swing.JFrame {

    private String NamaFinal;
    private String TelpFinal;
    private String filename;
    private JLabel dateLabel;
    
    Connection conn;
    
    public FrameBuatSepatu() {
        initComponents();
        conn = koneksi.getConnection();
        
        dateLabel = new JLabel();
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        dateLabel.setText(today.format(formatter));

        add(dateLabel);
    }
    
    class SaveData extends FrameBuat{
    String nama="", warna="", size="", harga="", foto="";
    public SaveData(){
        nama = tf_nama.getText();
        warna = tf_warna.getText();
        size = cmb_size.getSelectedItem().toString();
        harga = tf_harga.getText();

    }
    }

    @SuppressWarnings("unchecked")
    
        public void setImageData(String nama, String warna, String size, int harga, byte[] imageData, String tgl) {

        try { 
            String sql = "INSERT INTO vashion (nama, warna, size, harga, gambar, Tgl) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, nama);        
            ps.setString(2, warna);   
            ps.setString(3, size);         
            ps.setInt(4, harga); 
            ps.setBytes(5, imageData);
            ps.setString(6, tgl);

            ps.executeUpdate();
            System.out.println("Data berhasil disimpan ke dalam database.");

        } catch (SQLException e) {
            System.out.println("Gagal menyimpan data: " + e.getMessage());
        }
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        tf_nama = new javax.swing.JTextField();
        tf_harga = new javax.swing.JTextField();
        Gambar1 = new javax.swing.JLabel();
        Pilih = new javax.swing.JButton();
        View = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        cmb_size = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        tf_warna = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 102, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 204, 0), new java.awt.Color(255, 255, 0), null, new java.awt.Color(255, 204, 0)));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Nama     :");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, -1, -1));
        jPanel1.add(tf_nama, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 30, 280, 30));
        jPanel1.add(tf_harga, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 190, 280, 30));

        Gambar1.setBackground(new java.awt.Color(255, 255, 255));
        Gambar1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Gambar1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        Gambar1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel1.add(Gambar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, 220, 220));

        Pilih.setFont(new java.awt.Font("Lucida Fax", 1, 12)); // NOI18N
        Pilih.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vashion/Icon Simpan.png"))); // NOI18N
        Pilih.setText("Save Product");
        Pilih.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PilihActionPerformed(evt);
            }
        });
        jPanel1.add(Pilih, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 470, 220, 40));

        View.setFont(new java.awt.Font("Lucida Fax", 1, 18)); // NOI18N
        View.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vashion/Icon View.png"))); // NOI18N
        View.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        View.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ViewActionPerformed(evt);
            }
        });
        jPanel1.add(View, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 470, 60, 40));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Warna   :");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 90, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Harga   :");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 190, -1, -1));

        cmb_size.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "39", "40", "41" }));
        jPanel1.add(cmb_size, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 130, 280, 30));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Size       :");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 140, -1, -1));
        jPanel1.add(tf_warna, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 80, 280, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vashion/Create Text.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 230, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 410, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 525, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void PilihActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PilihActionPerformed

        SaveData a = new SaveData();
        if (a.nama.equals("") || a.warna.equals("") || a.size.equals("") || 
            a.harga.equals("")) {
            JOptionPane.showMessageDialog(null, "Harap Mengisikan Deskripsi");
        }else {
        try {
        int hargaProduk = 0;
            try {
                hargaProduk = Integer.parseInt(tf_harga.getText());
            }catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Harga harus berupa angka!");
                return; 
            }

            JFileChooser chooser = new JFileChooser();
            chooser.showOpenDialog(null);
            File f = chooser.getSelectedFile();
            byte[] img = Files.readAllBytes(f.toPath());
            ImageIcon icn = new ImageIcon(img);

            int labelWidth = 235;
            int labelHeight = 235;

            int imageWidth = icn.getIconWidth();
            int imageHeight = icn.getIconHeight();

            double scaleX = (double) labelWidth / (double) imageWidth;
            double scaleY = (double) labelHeight / (double) imageHeight;
            double scale = Math.min(scaleX, scaleY);

            Image scaledImage = icn.getImage().getScaledInstance((int) (scale * imageWidth), 
                    (int) (scale * imageHeight),Image.SCALE_SMOOTH);

            Gambar1.setIcon(new ImageIcon(scaledImage));

            String namaProduk = tf_nama.getText();
            String warnaProduk = tf_warna.getText();
            String ukuranProduk = cmb_size.getSelectedItem().toString();
            String tanggalProduk = dateLabel.getText();

            int response = JOptionPane.showConfirmDialog(null, "Create Your Product?", "Konfirmasi", 
                JOptionPane.YES_NO_OPTION);                   
            if (response == JOptionPane.YES_OPTION) {
                a.setImageData(namaProduk, warnaProduk, ukuranProduk, String.valueOf(hargaProduk), img, tanggalProduk);
                JOptionPane.showMessageDialog(null, "Create Product Is Saved");
            }else {
                JOptionPane.showMessageDialog(null, "Create Product Is Cancelled!");
            }        
        }catch (IOException ex) {
            Logger.getLogger(FrameBuat.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat memuat gambar: " + ex.getMessage());
        }
    }
    }//GEN-LAST:event_PilihActionPerformed

        
    private void ViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ViewActionPerformed

        FromAdmin formAdmin = new FromAdmin(NamaAsli, username, pasword, idUp, namaUp, warnaUp, sizeUp, hargaUp, gambar);
        formAdmin.setNamaFinal(username);    
        formAdmin.setTelpFinal(pasword);   
        formAdmin.setVisible(true);
        this.dispose();  
    }//GEN-LAST:event_ViewActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrameBuatSepatu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrameBuatSepatu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrameBuatSepatu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrameBuatSepatu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrameBuatSepatu().setVisible(false);
                new FrameLogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Gambar1;
    private javax.swing.JButton Pilih;
    private javax.swing.JButton View;
    private javax.swing.JComboBox<String> cmb_size;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField tf_harga;
    private javax.swing.JTextField tf_nama;
    private javax.swing.JTextField tf_warna;
    // End of variables declaration//GEN-END:variables
}
