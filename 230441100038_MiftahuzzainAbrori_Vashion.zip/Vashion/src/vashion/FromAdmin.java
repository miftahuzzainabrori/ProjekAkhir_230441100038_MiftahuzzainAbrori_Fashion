package vashion;
import java.awt.Image;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class FromAdmin extends javax.swing.JFrame {

    static String NamaAsli;
    static String username;
    static String pasword;
    static String idUp;
    static String namaUp;
    static String warnaUp;
    static String sizeUp;
    static String hargaUp;
    static  ImageIcon gambar;
    private JLabel dateLabel;
    
    Connection conn;
    private DefaultTableModel model;
    private DefaultTableModel Gaya;
    private DefaultTableModel Update;
    private DefaultTableModel Delete;

    public FromAdmin(String NamaAsli, String username, String pasword, String idUp, String namaUp, String warnaUp, 
        String sizeUp, String hargaUp, ImageIcon gambar) {
        
        initComponents();
        
        this.NamaAsli = NamaAsli;
        this.username = username;
        this.pasword = pasword;
        this.idUp = idUp;
        this.namaUp = namaUp;
        this.warnaUp = warnaUp;
        this.sizeUp = sizeUp;
        this.hargaUp = hargaUp;
        this.gambar = gambar;
        
         
        tf_nama.setText(this.NamaAsli);
        NamaFinal.setText(this.username);
        TelpFinal.setText(this.pasword);
        tf_id.setText(this.idUp);
        tf_nama.setText(this.namaUp);
        tf_warna.setText(this.warnaUp);
        cmb_size.setSelectedItem(this.sizeUp);
        tf_harga.setText(this.hargaUp);
        lbl_desk.setIcon(this.gambar);
        
        conn = koneksi.getConnection();

        model = new DefaultTableModel();
        tbl_gambar.setModel(model);
        
        model.addColumn("ID");
        model.addColumn("NAMA BARANG");
        model.addColumn("HARGA");
        
        getData();
        
        Gaya = new DefaultTableModel();
        tbl_riwayat.setModel(Gaya);
        
        Gaya.addColumn("NAMA PRODUCT");
        Gaya.addColumn("NAMA USER");
        Gaya.addColumn("TANGGAL");
        
        getDataTransaksi();
        
        Update = new DefaultTableModel();
        tbl_update.setModel(Update);
        
        Update.addColumn("NAMA PRODUCT");
        Update.addColumn("UPDATE PRODUK");
        Update.addColumn("USER UPDATE");
        Update.addColumn("TANGGAL");
        
        getDataUpdate();
        
        Delete = new DefaultTableModel();
        tbl_delete.setModel(Delete);
        
        Delete.addColumn("NAMA PRODUCT");
        Delete.addColumn("NAMA USER");
        Delete.addColumn("TANGGAL");
        
        getDataDelete();

    }
    
    public void setNamaFinal(String username) {
    NamaFinal.setText(username);
    }

    public void setTelpFinal(String pasword) {
    TelpFinal.setText(pasword);
    }



    private void getData() {
        model.setRowCount(0);
        cmb_id1.removeAllItems();

        
        try {
            String sql = "SELECT * FROM vashion";
            String sqli = "SELECT id_nama, nama, warna, size, harga, gambar FROM vashion";
            
            PreparedStatement psi = conn.prepareStatement(sqli);
            ResultSet rsi = psi.executeQuery();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            
            while(rs.next()) {
                int id = rs.getInt("id_nama");
                String nama = rs.getString("nama");
                String harga = rs.getString("harga");
                
                
                Object[] rowData = {id, nama, harga};
                model.addRow(rowData);
                
            }
            rs.close();
            ps.close();
            
            while (rsi.next()) {
            byte[] gambar = rsi.getBytes("gambar");
            String tampilan = String.format("%s", 
                rsi.getString("nama"),
                rsi.getString("warna"),
                rsi.getString("size"),
                rsi.getString("harga")
            );
            cmb_id1.addItem(tampilan);           
            }
            rsi.close();
            psi.close();
            
         
        } catch (Exception e) {
            System.out.println("Error Save Data" + e.getMessage());
        }     
    }
    
    private void getDataTransaksi(){
    Gaya.setRowCount(0);
 
    try {
        String sql = """
            SELECT b.nama AS NamaBuat, b.Tgl AS TanggalBuat, l.username AS UsernameLogin
            FROM transaksi t
            JOIN vashion b ON t.id_nama = b.id_nama
            JOIN login l ON t.id_user = l.id_user
        """;
        
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            String NamaBarang = rs.getString("NamaBuat");
            String Username = rs.getString("UsernameLogin");
            String TanggalBuat = rs.getString("TanggalBuat");  

            Gaya.addRow(new Object[]{NamaBarang, Username, TanggalBuat});
        }

        rs.close();
        rs.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    }
    
    private void getDataUpdate() {
        Update.setRowCount(0);

        try {
            String sql = """
                SELECT u.NamaAwal AS NamaA, u.namaUp AS NamaUpdate, u.tanggal AS TanggalBuat, l.username AS UsernameLogin
                FROM updata u
                JOIN login l ON u.id_user = l.id_user
            """;

            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String NamaAwal = rs.getString("NamaA");
                String NamaUpdate = rs.getString("NamaUpdate");
                String Username = rs.getString("UsernameLogin");
                String TanggalBuat = rs.getString("TanggalBuat");

                Update.addRow(new Object[]{NamaAwal, NamaUpdate, Username, TanggalBuat});
            }

            rs.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    
    private void getDataDelete() {
        Delete.setRowCount(0);
        
        try {
            String sql = "SELECT * FROM deldata";

            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            
            while(rs.next()) {
                String nama = rs.getString("NamaDel");
                String user = rs.getString("NamaUser");
                String tanggal = rs.getString("tanggal");
                
                
                Object[] rowData = {nama, user, tanggal};
                Delete.addRow(rowData);
                
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            System.out.println("Error Save Data" + e.getMessage());
        }
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        tf_harga = new javax.swing.JTextField();
        tf_nama = new javax.swing.JTextField();
        tf_warna = new javax.swing.JTextField();
        cmb_size = new javax.swing.JComboBox<>();
        tf_id = new javax.swing.JTextField();
        Tambah = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        TelpFinal = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        NamaFinal = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_gambar = new javax.swing.JTable();
        lbl_desk = new javax.swing.JLabel();
        btn_desk = new javax.swing.JButton();
        cmb_id1 = new javax.swing.JComboBox<>();
        btn_delete = new javax.swing.JButton();
        btn_update = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        log_nama = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btn_daftar = new javax.swing.JButton();
        btn_batal = new javax.swing.JButton();
        Chk_ya = new javax.swing.JCheckBox();
        jLabel14 = new javax.swing.JLabel();
        log_pasword = new javax.swing.JPasswordField();
        jLabel3 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        btn_exit = new javax.swing.JButton();
        btn_login = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_riwayat = new javax.swing.JTable();
        btn_close = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_delete = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbl_update = new javax.swing.JTable();
        jLabel16 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 102, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Bookman Old Style", 1, 12)); // NOI18N
        jLabel9.setText("Harga     :");
        jLabel9.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, -1, -1));

        jLabel10.setFont(new java.awt.Font("Bookman Old Style", 1, 12)); // NOI18N
        jLabel10.setText("ID          :");
        jLabel10.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, -1, -1));

        jLabel11.setFont(new java.awt.Font("Bookman Old Style", 1, 12)); // NOI18N
        jLabel11.setText("Nama     :");
        jLabel11.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        jLabel12.setFont(new java.awt.Font("Bookman Old Style", 1, 12)); // NOI18N
        jLabel12.setText("Warna   :");
        jLabel12.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, -1));

        jLabel13.setFont(new java.awt.Font("Bookman Old Style", 1, 12)); // NOI18N
        jLabel13.setText("Size       :");
        jLabel13.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, -1, -1));

        tf_harga.setEditable(false);
        jPanel2.add(tf_harga, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 190, 200, -1));

        tf_nama.setEditable(false);
        jPanel2.add(tf_nama, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 70, 200, -1));

        tf_warna.setEditable(false);
        jPanel2.add(tf_warna, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 110, 200, -1));

        cmb_size.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        cmb_size.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "39", "40", "41", "M", "L", "XL" }));
        jPanel2.add(cmb_size, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 150, 200, 30));

        tf_id.setEditable(false);
        jPanel2.add(tf_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 30, 200, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 300, 310, 230));

        Tambah.setFont(new java.awt.Font("Bookman Old Style", 1, 12)); // NOI18N
        Tambah.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vashion/Icon Tambah.png"))); // NOI18N
        Tambah.setText("   TAMBAH PRODUCT");
        Tambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TambahActionPerformed(evt);
            }
        });
        jPanel1.add(Tambah, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 470, 360, 50));

        jLabel1.setText("Password :");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, -1, -1));

        TelpFinal.setEditable(false);
        jPanel1.add(TelpFinal, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 70, 280, 30));

        jLabel2.setText("Username:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, -1, -1));

        NamaFinal.setEditable(false);
        NamaFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NamaFinalActionPerformed(evt);
            }
        });
        jPanel1.add(NamaFinal, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 30, 280, 30));

        tbl_gambar.setBackground(new java.awt.Color(204, 204, 204));
        tbl_gambar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl_gambar.setRowHeight(50);
        jScrollPane1.setViewportView(tbl_gambar);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 360, 280));

        lbl_desk.setBackground(new java.awt.Color(255, 255, 255));
        lbl_desk.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel1.add(lbl_desk, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 50, 230, 230));

        btn_desk.setFont(new java.awt.Font("Bookman Old Style", 1, 12)); // NOI18N
        btn_desk.setText("DESKRIPSI LENGKAP");
        btn_desk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_deskActionPerformed(evt);
            }
        });
        jPanel1.add(btn_desk, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 420, -1, 40));

        cmb_id1.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        cmb_id1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel1.add(cmb_id1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 420, 180, 40));

        btn_delete.setBackground(new java.awt.Color(255, 51, 51));
        btn_delete.setFont(new java.awt.Font("Bookman Old Style", 1, 12)); // NOI18N
        btn_delete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vashion/Icon Hapus.png"))); // NOI18N
        btn_delete.setText("Delete");
        btn_delete.setMargin(new java.awt.Insets(2, 2, 3, 2));
        btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_deleteActionPerformed(evt);
            }
        });
        jPanel1.add(btn_delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 220, 90, 40));

        btn_update.setBackground(new java.awt.Color(51, 255, 51));
        btn_update.setFont(new java.awt.Font("Bookman Old Style", 1, 12)); // NOI18N
        btn_update.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vashion/Icon Update.png"))); // NOI18N
        btn_update.setText("Update");
        btn_update.setMargin(new java.awt.Insets(2, 2, 3, 2));
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });
        jPanel1.add(btn_update, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 170, 90, 40));

        jTabbedPane1.addTab("Your Product", new javax.swing.ImageIcon(getClass().getResource("/vashion/Icon Product.png")), jPanel1); // NOI18N

        jPanel3.setBackground(new java.awt.Color(255, 102, 0));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel4.add(log_nama, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 90, 260, 40));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText(" Username : ");
        jLabel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel4.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, -1, 30));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setText(" Password  : ");
        jLabel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel4.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, -1, 30));

        btn_daftar.setBackground(new java.awt.Color(51, 51, 255));
        btn_daftar.setText("DAFTAR");
        btn_daftar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_daftarActionPerformed(evt);
            }
        });
        jPanel4.add(btn_daftar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 380, 60));

        btn_batal.setBackground(new java.awt.Color(255, 0, 0));
        btn_batal.setText("BATAL");
        btn_batal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_batalActionPerformed(evt);
            }
        });
        jPanel4.add(btn_batal, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, 380, 50));

        Chk_ya.setText("Yes");
        Chk_ya.setToolTipText("");
        jPanel4.add(Chk_ya, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, -1, -1));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vashion/Daftar Text.png"))); // NOI18N
        jPanel4.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 20, -1, -1));
        jPanel4.add(log_pasword, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 150, 260, 40));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vashion/Create Text.png"))); // NOI18N
        jPanel4.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 400, 380));

        jLabel8.setText("Miftahuzzain Abrori.Sumenep.Masalembu.##Zubaer");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 430, -1, -1));

        btn_exit.setFont(new java.awt.Font("Bookman Old Style", 1, 14)); // NOI18N
        btn_exit.setText("EXIT");
        btn_exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exitActionPerformed(evt);
            }
        });
        jPanel3.add(btn_exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 400, 100, 40));

        btn_login.setFont(new java.awt.Font("Bookman Old Style", 1, 14)); // NOI18N
        btn_login.setText("LOGIN");
        btn_login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_loginActionPerformed(evt);
            }
        });
        jPanel3.add(btn_login, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 400, 100, 40));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vashion/Virgo Logo.png"))); // NOI18N
        jPanel3.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 20, -1, -1));

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vashion/Join Us.png"))); // NOI18N
        jPanel3.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 280, -1, -1));

        jPanel6.setBackground(new java.awt.Color(204, 204, 204));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel3.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 480, 750, 50));

        jTabbedPane1.addTab("Daftar", new javax.swing.ImageIcon(getClass().getResource("/vashion/Icon Daftar.png")), jPanel3); // NOI18N

        jPanel5.setBackground(new java.awt.Color(255, 102, 0));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbl_riwayat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(tbl_riwayat);

        jPanel5.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 610, 360));

        btn_close.setBackground(java.awt.Color.red);
        btn_close.setFont(new java.awt.Font("Bookman Old Style", 1, 24)); // NOI18N
        btn_close.setForeground(new java.awt.Color(255, 255, 255));
        btn_close.setText("CLOSE APLIKASI");
        btn_close.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_closeActionPerformed(evt);
            }
        });
        jPanel5.add(btn_close, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 420, 610, 70));

        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel8.setBackground(new java.awt.Color(255, 255, 0));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel7.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 30, 30));

        jPanel9.setBackground(new java.awt.Color(255, 0, 204));

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel7.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, 30, 30));

        jPanel10.setBackground(new java.awt.Color(255, 51, 51));

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel7.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 0, 30, 30));

        jPanel11.setBackground(new java.awt.Color(153, 153, 255));

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel7.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 30, 30, 30));

        jPanel12.setBackground(new java.awt.Color(153, 255, 51));

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel7.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, 30, 30));

        jPanel13.setBackground(new java.awt.Color(0, 255, 153));

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel7.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 0, 30, 30));

        jPanel14.setBackground(new java.awt.Color(153, 153, 153));

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel7.add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 30, 30));

        jPanel15.setBackground(new java.awt.Color(255, 102, 102));

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jPanel7.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 30, 30));

        jPanel16.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jPanel7.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 30, 30));

        jPanel17.setBackground(new java.awt.Color(255, 255, 153));

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jPanel7.add(jPanel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, 30, 30));

        jPanel18.setBackground(new java.awt.Color(102, 255, 204));

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jPanel7.add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 30, 30));

        jPanel19.setBackground(new java.awt.Color(255, 204, 102));

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jPanel7.add(jPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 90, 30, 30));

        jPanel20.setBackground(new java.awt.Color(51, 0, 51));

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jPanel7.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 30, 30, 30));

        jPanel21.setBackground(new java.awt.Color(102, 102, 0));

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jPanel7.add(jPanel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 30, 30));

        jPanel22.setBackground(new java.awt.Color(255, 204, 204));

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jPanel7.add(jPanel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, 30, 30));

        jPanel23.setBackground(new java.awt.Color(0, 0, 153));

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jPanel7.add(jPanel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 60, 30, 30));

        jPanel5.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 40, 120, 120));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vashion/Create Text.png"))); // NOI18N
        jPanel5.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 160, -1, -1));

        jTabbedPane1.addTab("Riwayat Buat", new javax.swing.ImageIcon(getClass().getResource("/vashion/Icon Riwayat.png")), jPanel5); // NOI18N

        jPanel24.setBackground(new java.awt.Color(255, 102, 0));
        jPanel24.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbl_delete.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tbl_delete);

        jPanel24.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 490, 140));

        tbl_update.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane4.setViewportView(tbl_update);

        jPanel24.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 490, 140));

        jLabel16.setFont(new java.awt.Font("Bookman Old Style", 1, 24)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("---------TABEL RIWAYAT UPDATE---------");
        jLabel16.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel24.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 490, -1));

        jLabel18.setFont(new java.awt.Font("Bookman Old Style", 1, 24)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("---------TABEL RIWAYAT DELETE---------");
        jLabel18.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel24.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, 490, -1));

        jTabbedPane1.addTab("Upadate Or Delete", jPanel24);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_deskActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_deskActionPerformed
        
        try {
            String sql = "SELECT gambar, id_nama, nama, warna, size, harga FROM vashion WHERE nama = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, cmb_id1.getSelectedItem().toString());
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                
                byte[] gambarBytes = rs.getBytes("gambar");
                ImageIcon icon = new ImageIcon(gambarBytes);
                Image img = icon.getImage().getScaledInstance(lbl_desk.getWidth(), lbl_desk.getHeight(), Image.SCALE_SMOOTH);
                lbl_desk.setIcon(new ImageIcon(img));

                
                tf_id.setText(rs.getString("id_nama"));
                tf_nama.setText(rs.getString("nama"));
                tf_warna.setText(rs.getString("warna"));
                cmb_size.setSelectedItem(rs.getString("size"));
                tf_harga.setText(rs.getString("harga"));
            }

            rs.close();
            ps.close();
        }catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal menampilkan data: " + e.getMessage());
}
       
    }//GEN-LAST:event_btn_deskActionPerformed

    private void TambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TambahActionPerformed

    String[] options = {"Baju", "Sepatu"};
    int choice = JOptionPane.showOptionDialog(this,"Pilih Katagori Produk","Pilih Produk",JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,null, options, options[0]);

    if (choice == 0) {
        FrameBuat buat = new FrameBuat();
        buat.setVisible(true);
    } else if (choice == 1) {
        FrameBuatSepatu buatSepatu = new FrameBuatSepatu();
        buatSepatu.setVisible(true);
    }
    this.dispose();

    }//GEN-LAST:event_TambahActionPerformed

    private void btn_daftarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_daftarActionPerformed
        
        String logUsername = log_nama.getText();
        String logPasword = log_pasword.getText();

        if (logUsername.isEmpty() || logPasword.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Harap Isi Semua Data !!");
        }else if (!Chk_ya.isSelected()) {
            JOptionPane.showMessageDialog(null, "Centang (YA) Jika Sudah Benar !!");
        }else {
            
            String sql = "INSERT INTO login (username, pasword) VALUES (?, ?)";
            try {
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, logUsername);
                ps.setString(2, logPasword);

                int rowsAffected = ps.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "Berhasil Mendaftar");

                    log_nama.setText("");
                    log_pasword.setText("");
                    
                    jTabbedPane1.setSelectedIndex(0);
                    
                }else {
                    JOptionPane.showMessageDialog(null, "Pendaftaran gagal. Silakan coba lagi.");
                }
                ps.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat menyimpan data: " + e.getMessage());
            }
        }     
    }//GEN-LAST:event_btn_daftarActionPerformed

    private void NamaFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NamaFinalActionPerformed
        // TODO add your handling code here
    }//GEN-LAST:event_NamaFinalActionPerformed

    private void btn_batalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_batalActionPerformed
        
        log_nama.setText("");
        log_pasword.setText("");
    }//GEN-LAST:event_btn_batalActionPerformed

    private void btn_exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exitActionPerformed
                                       
    int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin keluar?", "Konfirmasi Keluar", 
        JOptionPane.YES_NO_OPTION);
    
    if (confirm == JOptionPane.YES_OPTION) {
        System.exit(0);
    }
    }//GEN-LAST:event_btn_exitActionPerformed

    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed

    if (NamaFinal.getText().isEmpty() || TelpFinal.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Daftar Telebih Dahulu !!");
    }else if (tf_id.getText().isEmpty() || tf_nama.getText().isEmpty() || tf_warna.getText().isEmpty() || tf_harga.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Pilih Produk Terlebih Dahulu !!");
    }else {
        FrameUpdate Update = new FrameUpdate();

        Update.up_id.setText(tf_id.getText());
        Update.up_nama.setText(tf_nama.getText());
        Update.up_warna.setText(tf_warna.getText());
        Update.cmb_up_size.setSelectedItem(cmb_size.getSelectedItem().toString());
        Update.up_harga.setText(tf_harga.getText());
        Update.up_gambar.setIcon(lbl_desk.getIcon());
        Update.NamaAsli = tf_nama.getText();

        Update.setVisible(true);
        this.dispose(); 
    }
    }//GEN-LAST:event_btn_updateActionPerformed

    private void btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_deleteActionPerformed
        
        if (NamaFinal.getText().isEmpty() || TelpFinal.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Daftar Telebih Dahulu !!");
        }else {
            try {
                String selectedId = tf_id.getText(); 
                String sql = "DELETE FROM vashion WHERE id_nama = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, selectedId);

                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Data berhasil dihapus.");

                    tf_id.setText("");  
                    tf_nama.setText("");  
                    tf_warna.setText("");  
                    cmb_size.setSelectedIndex(0); 
                    tf_harga.setText("");  
                    lbl_desk.setIcon(null);

                    getData();
                }else {
                    JOptionPane.showMessageDialog(this, "Tidak Ada Data Yang Dipilih !!");
                }
                ps.close();
            }catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Gagal menghapus data: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_btn_deleteActionPerformed

    private void btn_loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_loginActionPerformed
        
        FrameLogin loginFrame = new FrameLogin();
        loginFrame.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btn_loginActionPerformed

    private void btn_closeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_closeActionPerformed
        // TODO add your handling code here:
        int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin keluar?", "Konfirmasi Keluar", 
        JOptionPane.YES_NO_OPTION);
    
    if (confirm == JOptionPane.YES_OPTION) {
        System.exit(0);
    }
    }//GEN-LAST:event_btn_closeActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrameLogin().setVisible(true);
                new FromAdmin(NamaAsli, username, pasword, idUp, namaUp, warnaUp, sizeUp, hargaUp, gambar).setVisible(false);
            }
        
        });

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox Chk_ya;
    public javax.swing.JTextField NamaFinal;
    private javax.swing.JButton Tambah;
    public javax.swing.JTextField TelpFinal;
    private javax.swing.JButton btn_batal;
    private javax.swing.JButton btn_close;
    private javax.swing.JButton btn_daftar;
    private javax.swing.JButton btn_delete;
    private javax.swing.JButton btn_desk;
    private javax.swing.JButton btn_exit;
    private javax.swing.JButton btn_login;
    private javax.swing.JButton btn_update;
    private javax.swing.JComboBox<String> cmb_id1;
    private javax.swing.JComboBox<String> cmb_size;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lbl_desk;
    private javax.swing.JTextField log_nama;
    private javax.swing.JPasswordField log_pasword;
    private javax.swing.JTable tbl_delete;
    private javax.swing.JTable tbl_gambar;
    private javax.swing.JTable tbl_riwayat;
    private javax.swing.JTable tbl_update;
    private javax.swing.JTextField tf_harga;
    private javax.swing.JTextField tf_id;
    private javax.swing.JTextField tf_nama;
    private javax.swing.JTextField tf_warna;
    // End of variables declaration//GEN-END:variables
}
