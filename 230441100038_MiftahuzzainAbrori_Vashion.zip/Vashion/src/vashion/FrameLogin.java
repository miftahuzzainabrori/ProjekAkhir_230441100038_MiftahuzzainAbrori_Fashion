package vashion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import static vashion.FromAdmin.NamaAsli;
import static vashion.FromAdmin.gambar;
import static vashion.FromAdmin.hargaUp;
import static vashion.FromAdmin.idUp;
import static vashion.FromAdmin.namaUp;
import static vashion.FromAdmin.sizeUp;
import static vashion.FromAdmin.warnaUp;

public class FrameLogin extends javax.swing.JFrame {

    
    Connection conn;
    
    public FrameLogin() {
        initComponents();
        conn = koneksi.getConnection();
    }
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        tf_username = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btn_loggin = new javax.swing.JButton();
        tf_pasword = new javax.swing.JPasswordField();
        btn_keluar = new javax.swing.JButton();
        btn_batal = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btn_register = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(51, 0, 51));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(tf_username, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 110, 270, 40));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Pasword   :");
        jLabel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, -1, 20));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Username :");
        jLabel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, -1, 20));

        btn_loggin.setBackground(new java.awt.Color(21, 255, 0));
        btn_loggin.setFont(new java.awt.Font("Bookman Old Style", 1, 14)); // NOI18N
        btn_loggin.setForeground(new java.awt.Color(255, 255, 255));
        btn_loggin.setText("LOGIN");
        btn_loggin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_logginActionPerformed(evt);
            }
        });
        jPanel1.add(btn_loggin, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 110, 40));
        jPanel1.add(tf_pasword, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 170, 270, 40));

        btn_keluar.setBackground(new java.awt.Color(255, 51, 51));
        btn_keluar.setFont(new java.awt.Font("Bookman Old Style", 1, 14)); // NOI18N
        btn_keluar.setForeground(new java.awt.Color(255, 255, 255));
        btn_keluar.setText("EXIT");
        btn_keluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_keluarActionPerformed(evt);
            }
        });
        jPanel1.add(btn_keluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 250, 110, 40));

        btn_batal.setBackground(new java.awt.Color(51, 51, 255));
        btn_batal.setFont(new java.awt.Font("Bookman Old Style", 1, 14)); // NOI18N
        btn_batal.setForeground(new java.awt.Color(255, 255, 255));
        btn_batal.setText("CANCEL");
        btn_batal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_batalActionPerformed(evt);
            }
        });
        jPanel1.add(btn_batal, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 250, 110, 40));

        jPanel2.setBackground(new java.awt.Color(255, 102, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vashion/Logo Login.png"))); // NOI18N
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vashion/From Login.png"))); // NOI18N
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 410, 60));

        btn_register.setBackground(new java.awt.Color(0, 0, 0));
        btn_register.setFont(new java.awt.Font("Bookman Old Style", 1, 14)); // NOI18N
        btn_register.setForeground(new java.awt.Color(255, 255, 255));
        btn_register.setText("REGISTER USER");
        btn_register.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_registerActionPerformed(evt);
            }
        });
        jPanel1.add(btn_register, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 180, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 382, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_logginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_logginActionPerformed
        
    try {
        String username = tf_username.getText();
        String passwordText = tf_pasword.getText();

        if (username.isEmpty() && passwordText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Isi Username Dan Password!", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int password;
        try {
            password = Integer.parseInt(passwordText);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Password harus berupa angka!", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String sqlLogin = "SELECT * FROM login WHERE username = ? AND pasword = ?";
        PreparedStatement psLogin = conn.prepareStatement(sqlLogin);
        psLogin.setString(1, username);
        psLogin.setInt(2, password);
        ResultSet rsLogin = psLogin.executeQuery();

        if (rsLogin.next()) {
            int response = JOptionPane.showConfirmDialog(this, "Login?", "Konfirmasi", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (response == JOptionPane.YES_OPTION) {
                JOptionPane.showMessageDialog(null, "Hallo " + username + ", Silahkan Masuk Aplikasi");
                FromAdmin formAdmin = new FromAdmin(NamaAsli, username, passwordText, idUp, namaUp, warnaUp, sizeUp, hargaUp, gambar);
                formAdmin.setVisible(true);
                this.dispose();
            }
        }else {
            String sqlUser = "SELECT * FROM user WHERE Nama = ? AND pasword = ?";
            PreparedStatement psUser = conn.prepareStatement(sqlUser);
            psUser.setString(1, username);
            psUser.setInt(2, password);
            ResultSet rsUser = psUser.executeQuery();

            if (rsUser.next()) {
                JOptionPane.showMessageDialog(null, "Hallo " + username + ", Silahkan Masuk Aplikasi");
                FromUser formUser = new FromUser(username, passwordText);
                formUser.setVisible(true);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Username atau Pasword Salah, Register Terlebih Dahulu !!", "Login Error", JOptionPane.ERROR_MESSAGE);
            }

            rsUser.close();
            psUser.close();
        }

        rsLogin.close();
        psLogin.close();

    }catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Terjadi kesalahan: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    }//GEN-LAST:event_btn_logginActionPerformed

    private void btn_keluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_keluarActionPerformed

        int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin keluar?", "Konfirmasi Keluar", 
            JOptionPane.YES_NO_OPTION);    
        if (confirm == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_btn_keluarActionPerformed

    private void btn_batalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_batalActionPerformed

        String username = tf_username.getText().trim();
        String password = tf_pasword.getText().trim();

        if (!username.isEmpty() || !password.isEmpty()) {
            tf_username.setText("");
            tf_pasword.setText("");
            JOptionPane.showMessageDialog(this, "Login Cancelled", "Informasi", JOptionPane.INFORMATION_MESSAGE);
        }else {
            JOptionPane.showMessageDialog(this, "Belum ada nilai yang dimasukkan.", "Informasi", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btn_batalActionPerformed

    private void btn_registerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_registerActionPerformed

        FromRegister register = new FromRegister ();
        register.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btn_registerActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrameLogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_batal;
    private javax.swing.JButton btn_keluar;
    private javax.swing.JButton btn_loggin;
    private javax.swing.JButton btn_register;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPasswordField tf_pasword;
    private javax.swing.JTextField tf_username;
    // End of variables declaration//GEN-END:variables
}
